# Pterodactyl

Includes FiveM egg, installation script, and panel setup guide.